"""Response surface for the system model: household LP over a grid of
battery capital cost (cb) x retail-price multiplier (m) for net billing
(NB) and time-differentiated net billing at two evening export credits.

Output: results/household_grid.csv
"""
import sys
import itertools
import pandas as pd
from multiprocessing import Pool
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import params as P
from run_household import run_one, L, OUT

CBS = (50_000, 40_000, 30_000, 20_000)
MS = (1.0, 1.1, 1.2, 1.3, 1.4, 1.5)
REGS = (("NB", "NB", None), ("TNB35", "TNB", 35.0),
        ("TNB46", "TNB", P.RLNG_COST))


def scen():
    S = []
    for (lab, reg, ep), cb, m in itertools.product(REGS, CBS, MS):
        S.append(dict(name=f"{lab}|cb{cb}|m{m:g}", regime=reg, exp_peak=ep,
                      capex_bat=cb, tmult=m, label=lab))
    return S


if __name__ == "__main__":
    jobs = list(itertools.product(list(L.columns), scen()))
    print(len(jobs), "LPs", flush=True)
    rows = []
    with Pool(2) as pool:
        for i, res in enumerate(pool.imap_unordered(run_one, jobs, chunksize=6)):
            r = res if isinstance(res, dict) else res[0]
            rows.append(r)
            if i % 200 == 0:
                print(i, flush=True)
    df = pd.DataFrame(rows)
    lab = df.scenario.str.split("|", expand=True)
    df["label"] = lab[0]
    df.to_csv(OUT / "household_grid.csv", index=False)
    print("done", df.shape, "failures:", int((df.status != 0).sum()))
