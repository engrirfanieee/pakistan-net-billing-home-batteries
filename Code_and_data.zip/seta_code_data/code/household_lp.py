"""Joint capacity-and-dispatch linear programme for one household.

For a given compensation regime the LP chooses PV capacity (kWp), battery
energy capacity (kWh) and the hourly energy flows that minimise the
household's equivalent annual cost: annualised capital and O&M cost plus
the annual energy bill. Dispatch is solved with perfect foresight over the
8760-h year, which gives the economic upper bound of storage value.

Regimes
  'NM'   legacy net metering: kWh netted monthly within each ToU period;
         a net surplus is credited at NAPPP.
  'NB'   net billing (Prosumer Regulations 2026): imports at ToU retail
         price, every exported kWh credited at NAEPP.
  'TNB'  time-differentiated net billing (proposed): as NB, but exports in
         the ToU peak window are credited at an evening export price.
  'OFF'  grid defection: no imports or exports; unmet energy <= LPSP.
The battery is charged only from on-site PV (no grid charging), and the
instantaneous export (PV plus battery) is limited to the sanctioned load.
"""
import numpy as np
import scipy.sparse as sp
from scipy.optimize import linprog
import params as P

NV = 8  # hourly variables: pu pc pe gi bl be s un


def peak_mask(index):
    m = np.zeros(len(index), bool)
    for i, ts in enumerate(index):
        a, b = P.PEAK_WINDOW[ts.month]
        m[i] = a <= ts.hour < b
    return m


def solve(load, pv1, index, regime, imp_peak=P.IMP_PEAK, imp_off=P.IMP_OFF,
          exp_off=P.NAEPP, exp_peak=None, capex_pv=P.CAPEX_PV,
          capex_bat=P.CAPEX_BAT, pv_max=None, fix_pv=None, fix_bat=None,
          allow_bat=True, allow_pv=True, export_max=None):
    n = len(load)
    pk = peak_mask(index)
    imp = np.where(pk, imp_peak, imp_off)
    if regime == "TNB":
        ep = P.NAPPP if exp_peak is None else exp_peak
        exp = np.where(pk, ep, exp_off)
    else:
        exp = np.full(n, exp_off)
    der = P.pv_derate()
    y = pv1 * der
    eta = np.sqrt(P.ETA_RT)

    # variable layout: block k (0..7) of length n, then Ppv, Ebat
    def ix(k):
        return np.arange(k * n, (k + 1) * n)
    iPV, iE = NV * n, NV * n + 1
    extra = 0
    months = index.month.values
    if regime == "NM":
        # pos/neg net per (month, period): 24 pairs
        extra = 48
    nvar = NV * n + 2 + extra

    c = np.zeros(nvar)
    a_pv = capex_pv * (P.crf(P.DISCOUNT, P.LIFE_PV) + P.OM_PV)
    a_bat = (capex_bat + P.CAPEX_HYB * P.C_RATE) * P.crf(P.DISCOUNT, P.LIFE_BAT)
    c[iPV], c[iE] = a_pv, a_bat
    if regime in ("NB", "TNB"):
        c[ix(3)] = imp
        c[ix(2)] = -exp
        c[ix(5)] = -exp
    elif regime == "NM":
        base = NV * n + 2
        for m in range(12):
            for p in range(2):
                k = 2 * m + p
                c[base + 2 * k] = imp_peak if p else imp_off     # pos
                c[base + 2 * k + 1] = -P.NAPPP                    # neg
    elif regime == "OFF":
        c[ix(7)] = 1e-3
    # tiny throughput cost to remove degenerate simultaneous flows
    c[ix(1)] += 1e-4
    c[ix(4)] += 1e-4
    c[ix(5)] += 1e-4

    rows_eq, rows_ub = [], []
    beq, bub = [], []
    I = sp.identity(n, format="csr")

    def blk(entries, scal=None):
        """entries: dict k->sparse (n x n); scal: dict col->vector."""
        mats = []
        for k in range(NV):
            mats.append(entries.get(k, sp.csr_matrix((n, n))))
        A = sp.hstack(mats, format="csr")
        S = sp.lil_matrix((n, 2 + extra))
        if scal:
            for col, vec in scal.items():
                S[:, col] = vec.reshape(-1, 1)
        return sp.hstack([A, S.tocsr()], format="csr")

    # (1) load balance
    rows_eq.append(blk({0: I, 3: I, 4: I, 7: I})); beq.append(load)
    # (2) PV availability (curtailment allowed)
    rows_ub.append(blk({0: I, 1: I, 2: I}, {0: -y})); bub.append(np.zeros(n))
    # (3) state of charge, cyclic
    D = sp.identity(n, format="lil")
    for t in range(n):
        D[t, (t - 1) % n] = -1
    rows_eq.append(blk({6: D.tocsr(), 1: -eta * I, 4: I / eta, 5: I / eta}))
    beq.append(np.zeros(n))
    # (4) SOC bound, (5) charge and (6) discharge power bounds
    rows_ub.append(blk({6: I}, {1: -P.DOD * np.ones(n)})); bub.append(np.zeros(n))
    rows_ub.append(blk({1: I}, {1: -P.C_RATE * np.ones(n)})); bub.append(np.zeros(n))
    rows_ub.append(blk({4: I, 5: I}, {1: -P.C_RATE * np.ones(n)})); bub.append(np.zeros(n))
    # (7) export limited to the sanctioned load (connection capacity)
    if export_max is not None:
        rows_ub.append(blk({2: I, 5: I})); bub.append(np.full(n, export_max))

    A_eq = sp.vstack(rows_eq, format="csr")
    A_ub = sp.vstack(rows_ub, format="csr")
    beq = np.concatenate(beq)
    bub = np.concatenate(bub)

    if regime == "NM":
        base = NV * n + 2
        R = sp.lil_matrix((24, nvar))
        for m in range(12):
            for p in range(2):
                k = 2 * m + p
                sel = np.where((months == m + 1) & (pk == bool(p)))[0]
                for kk in (3,):
                    R[k, kk * n + sel] = 1.0
                for kk in (2, 5):
                    R[k, kk * n + sel] = -1.0
                R[k, base + 2 * k] = -1.0
                R[k, base + 2 * k + 1] = 1.0
        A_eq = sp.vstack([A_eq, R.tocsr()], format="csr")
        beq = np.concatenate([beq, np.zeros(24)])

    if regime == "OFF":
        row = sp.lil_matrix((1, nvar))
        row[0, ix(7)] = 1.0
        A_ub = sp.vstack([A_ub, row.tocsr()], format="csr")
        bub = np.concatenate([bub, [P.LPSP * load.sum()]])

    lb = np.zeros(nvar)
    ub = np.full(nvar, np.inf)
    if regime != "OFF":
        ub[ix(7)] = 0.0
    else:
        ub[ix(2)] = ub[ix(3)] = ub[ix(5)] = 0.0
    if pv_max is not None:
        ub[iPV] = pv_max
    if not allow_pv:
        ub[iPV] = 0.0
    if not allow_bat:
        ub[iE] = 0.0
    if fix_pv is not None:
        lb[iPV] = ub[iPV] = fix_pv
    if fix_bat is not None:
        lb[iE] = ub[iE] = fix_bat

    res = linprog(c, A_ub=A_ub, b_ub=bub, A_eq=A_eq, b_eq=beq,
                  bounds=np.column_stack([lb, ub]), method="highs")
    if res.status != 0:
        return {"status": res.status, "message": res.message}
    x = res.x
    f = {k: x[ix(i)] for i, k in enumerate(["pu", "pc", "pe", "gi", "bl", "be", "s", "un"])}
    Ppv, Eb = x[iPV], x[iE]
    capex_ann = a_pv * Ppv + a_bat * Eb
    if regime == "NM":
        energy_cost = res.fun - capex_ann
    elif regime == "OFF":
        energy_cost = 0.0
    else:
        energy_cost = float(imp @ f["gi"] - exp @ (f["pe"] + f["be"]))
    gen = float(y.sum() * Ppv)
    exported = float((f["pe"] + f["be"]).sum())
    out = dict(status=0, regime=regime, pv_kw=Ppv, bat_kwh=Eb,
               capex_ann=capex_ann, energy_cost=energy_cost,
               total_ann=capex_ann + energy_cost,
               load=float(load.sum()), pv_gen=gen,
               curtailed=float(gen - (f["pu"] + f["pc"] + f["pe"]).sum()),
               grid_import=float(f["gi"].sum()),
               grid_import_peak=float(f["gi"][pk].sum()),
               export=exported,
               export_peak=float((f["pe"] + f["be"])[pk].sum()),
               bat_to_load=float(f["bl"].sum()),
               bat_to_load_peak=float(f["bl"][pk].sum()),
               bat_export=float(f["be"].sum()),
               unmet=float(f["un"].sum()),
               peak_net_import_kw_mean=float((f["gi"] - f["pe"] - f["be"])[pk].mean()))
    used = gen - out["curtailed"]
    out["self_consumption"] = ((f["pu"].sum() + f["bl"].sum() / P.ETA_RT) / used
                               if used > 0 else np.nan)
    out["self_sufficiency"] = 1 - (out["grid_import"] + out["unmet"]) / out["load"]
    out["flows"] = f
    return out
