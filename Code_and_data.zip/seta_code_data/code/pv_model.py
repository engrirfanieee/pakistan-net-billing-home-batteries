"""Hourly PV yield for Lahore from the PVGIS typical meteorological year (TMY).

Input : data/pvgis_tmy_lahore.csv  (PVGIS v5.x TMY, 31.520N 74.360E, 2005-2023)
Output: data/pv_profile_lahore.csv (local time PKT, kWh per kWp for each hour)

Model chain (pvlib): solar position -> Perez transposition -> Faiman cell
temperature -> PVWatts DC model -> PVWatts system losses -> PVWatts inverter.
"""
import numpy as np
import pandas as pd
import pvlib
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
LAT, LON, ELEV = 31.52, 74.36, 214.0
TILT, AZIM = 28.0, 180.0          # fixed, south-facing
GAMMA_PDC = -0.0035               # power temperature coefficient (1/K)
DC_AC = 1.10                      # DC/AC ratio


def load_tmy(path):
    raw = pd.read_csv(path, skiprows=17, nrows=8760)
    t = pd.to_datetime(raw["time(UTC)"], format="%Y%m%d:%H%M")
    # PVGIS TMY rows come from different years; place them on one
    # reference non-leap year so that the series is continuous.
    t = t.map(lambda x: x.replace(year=2023))
    raw.index = pd.DatetimeIndex(t).tz_localize("UTC")
    raw = raw.sort_index()
    return raw.rename(columns={"G(h)": "ghi", "Gb(n)": "dni",
                               "Gd(h)": "dhi", "T2m": "temp_air",
                               "WS10m": "wind_speed"})


def pv_profile():
    w = load_tmy(ROOT / "data" / "pvgis_tmy_lahore.csv")
    w[["ghi", "dni", "dhi"]] = w[["ghi", "dni", "dhi"]].clip(lower=0)
    # Irradiance time offset of 0.5 h reported by PVGIS: evaluate the sun
    # position at the middle of each hourly interval.
    tpos = w.index + pd.Timedelta(minutes=30)
    sp = pvlib.solarposition.get_solarposition(tpos, LAT, LON, ELEV)
    sp.index = w.index
    dni_extra = pvlib.irradiance.get_extra_radiation(w.index)
    am = pvlib.atmosphere.get_relative_airmass(sp["apparent_zenith"])
    poa = pvlib.irradiance.get_total_irradiance(
        TILT, AZIM, sp["apparent_zenith"], sp["azimuth"],
        w["dni"], w["ghi"], w["dhi"], dni_extra=dni_extra,
        airmass=am, model="perez", albedo=0.2)
    poa_g = poa["poa_global"].fillna(0).clip(lower=0)
    tcell = pvlib.temperature.faiman(poa_g, w["temp_air"], w["wind_speed"])
    pdc0 = 1000.0                                     # W per kWp
    pdc = pvlib.pvsystem.pvwatts_dc(poa_g, tcell, pdc0, GAMMA_PDC)
    loss = pvlib.pvsystem.pvwatts_losses() / 100.0    # default 14.08 %
    pdc = pdc * (1 - loss)
    pac = pvlib.inverter.pvwatts(pdc, pdc0 / DC_AC, eta_inv_nom=0.96)
    pac = pac.clip(lower=0).fillna(0)
    out = pd.DataFrame({"pv_kwh_per_kwp": pac / 1000.0,
                        "ghi": w["ghi"], "poa": poa_g,
                        "temp_air": w["temp_air"]})
    out.index = out.index.tz_convert("Asia/Karachi")
    # roll so that the local-time year starts at 00:00 on 1 January
    out = out.sort_index()
    vals = out.values
    shift = int((out.index[0].hour))  # PKT = UTC+5 -> first row is 05:00
    vals = np.roll(vals, shift, axis=0)
    idx = pd.date_range("2023-01-01 00:00", periods=8760, freq="h")
    prof = pd.DataFrame(vals, index=idx, columns=out.columns)
    prof.index.name = "local_time_PKT"
    return prof


if __name__ == "__main__":
    p = pv_profile()
    p.to_csv(ROOT / "data" / "pv_profile_lahore.csv")
    print("Annual GHI (kWh/m2):", round(p["ghi"].sum() / 1000, 1))
    print("Annual POA (kWh/m2):", round(p["poa"].sum() / 1000, 1))
    print("Specific yield (kWh/kWp):", round(p["pv_kwh_per_kwp"].sum(), 1))
    print(p["pv_kwh_per_kwp"].groupby(p.index.month).sum().round(1).to_dict())
    print("Mean hourly profile:", p["pv_kwh_per_kwp"].groupby(p.index.hour).mean().round(3).to_dict())
