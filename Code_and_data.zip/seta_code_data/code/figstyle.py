"""Shared figure style (journal print: white surface, thin marks)."""
import matplotlib as mpl

S1, S2, S3, S4, S5, S7 = ("#2a78d6", "#eb6834", "#1baf7a", "#eda100",
                          "#e87ba4", "#6250d6")
INK, INK2, GRIDC = "#0b0b0b", "#52514e", "#e4e3df"
PEAK_FILL = "#f1efe9"


def apply():
    mpl.rcParams.update({
        "font.family": "DejaVu Sans", "font.size": 8,
        "axes.edgecolor": INK2, "axes.labelcolor": INK, "axes.linewidth": 0.6,
        "xtick.color": INK2, "ytick.color": INK2,
        "xtick.major.width": 0.6, "ytick.major.width": 0.6,
        "axes.grid": True, "grid.color": GRIDC, "grid.linewidth": 0.5,
        "axes.spines.top": False, "axes.spines.right": False,
        "legend.frameon": False, "lines.linewidth": 1.6,
        "savefig.dpi": 600, "figure.dpi": 150,
        "pdf.fonttype": 42, "ps.fonttype": 42,
    })
