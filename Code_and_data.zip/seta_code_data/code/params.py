"""Model parameters. Every value is taken from a cited source (see the
manuscript Table 1, with source keys given here) or is a stated modelling
choice that is varied in the sensitivity analysis."""

# ---- Retail import tariff: residential time-of-use, sanctioned load >= 5 kW
# S.R.O. 279(I)/2026, as published in the IESCO tariff guide (Feb 2026).
IMP_PEAK = 46.85          # PKR/kWh
IMP_OFF = 34.53           # PKR/kWh
# Peak windows, NEPRA Terms and Conditions of Tariff (S.R.O. 566-575(I)/2015):
# Dec-Feb 17-21 h, Mar-May 18-22 h, Jun-Aug 19-23 h, Sep-Nov 18-22 h.
PEAK_WINDOW = {12: (17, 21), 1: (17, 21), 2: (17, 21),
               3: (18, 22), 4: (18, 22), 5: (18, 22),
               6: (19, 23), 7: (19, 23), 8: (19, 23),
               9: (18, 22), 10: (18, 22), 11: (18, 22)}
# Fixed charge for ToU domestic consumers: PKR 675/kW/month on 50 % of
# sanctioned load (The News, 12 Feb 2026; NEPRA uniform tariff decision).
FIXED_CHARGE = 675.0      # PKR/kW/month
FIXED_SHARE = 0.5

# ---- Export compensation
NAEPP = 11.0              # PKR/kWh, Prosumer Regulations 2026 (net billing)
NAPPP = 25.98             # PKR/kWh, FY2025-26 national average power
                          # purchase price (credit for net-metering surplus)
RLNG_COST = 45.93         # PKR/kWh, RLNG generation fuel cost, Aug 2026 (AHL)

# ---- Finance
DISCOUNT = 0.115          # SBP policy rate (2026)
LIFE_PV = 20              # years
LIFE_BAT = 10             # years (replacement assumed at year 10)
CAPEX_PV = 105_000.0      # PKR/kWp, turnkey on-grid, mid-2026 market survey
CAPEX_BAT = 50_000.0      # PKR/kWh, lithium battery, mid-2026 market survey
CAPEX_HYB = 10_000.0      # PKR/kW, hybrid-inverter premium over on-grid unit
OM_PV = 0.01              # fraction of PV capex per year
PV_DEGR = 0.005           # 1/yr linear degradation

# ---- Battery technology (LFP)
ETA_RT = 0.90             # round-trip efficiency
DOD = 0.90                # usable fraction of nameplate energy
C_RATE = 0.5              # kW per kWh

# ---- Off-grid design criterion
LPSP = 0.01               # loss-of-power-supply probability (energy basis)


def crf(r, n):
    return r * (1 + r) ** n / ((1 + r) ** n - 1)


def pv_derate():
    """Lifetime-average output factor for linear degradation."""
    return sum(1 - PV_DEGR * k for k in range(LIFE_PV)) / LIFE_PV
