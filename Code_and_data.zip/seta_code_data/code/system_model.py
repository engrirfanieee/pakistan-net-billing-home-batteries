"""Annual stock-and-flow simulation of the grid-tied prosumer fleet,
XWDISCO fixed-cost recovery and the retail-tariff feedback loop, 2026-2035.

Loop (one-year delay): prosumer capacity -> lost contribution to fixed
(capacity) cost -> uniform per-unit surcharge on the remaining purchased
units -> retail-price multiplier m -> prosumer response at (m, battery
cost) from the household LP response surface -> next year.

Household behaviour enters only through per-kWp coefficients derived from
the 34 PRECON households, bilinearly interpolated over battery capital
cost cb and retail multiplier m (results/household_grid.csv).
"""
import numpy as np
import pandas as pd
from pathlib import Path
import params as P

ROOT = Path(__file__).resolve().parents[1]
RES = ROOT / "results"

# ---- Sector data, FY2025-26 power purchase price determination (NEPRA)
PPP_XW_TOTAL = 3.066e12          # PKR
PPP_XW_UNIT = 26.34              # PKR/kWh
UNITS_XW = PPP_XW_TOTAL / PPP_XW_UNIT        # kWh purchased (~116.4 TWh)
CAP_CHARGE = 16.67               # PKR/kWh capacity component
ENERGY_CHARGE = 9.67             # PKR/kWh energy component (system average)
FIXED_COST = CAP_CHARGE * UNITS_XW
AVG_RETAIL = 0.185 * P.IMP_PEAK + 0.815 * P.IMP_OFF  # measured PRECON peak-window share
PEAK_HOURS = 4 * 365
YEARS = np.arange(2026, 2036)

COLS = ["pv_kw", "bat_kwh", "load", "grid_import", "grid_import_peak",
        "export", "export_peak"]


def surfaces():
    G = pd.read_csv(RES / "household_grid.csv")
    G = G[G.status == 0]
    H = pd.read_csv(RES / "household_runs.csv")
    grid_peak = H[H.scenario == "GRID"].set_index("house").grid_import_peak
    agg = G.groupby(["label", "capex_bat", "tmult"])[COLS].sum().reset_index()
    agg["load_peak"] = grid_peak.sum()
    for c in ["bat_kwh", "load", "grid_import", "grid_import_peak",
              "export", "export_peak", "load_peak"]:
        agg[c + "_pk"] = agg[c] / agg["pv_kw"]
    # per-house equivalent annual cost incl. fixed charges, for defection test
    cost = G.pivot_table(index=["label", "capex_bat", "tmult"], columns="house",
                         values="total_with_fixed")
    nm = H[H.scenario == "NM"][COLS].sum()
    nm_tab = {c + "_pk": nm[c] / nm["pv_kw"] for c in COLS}
    nm_tab["load_peak_pk"] = grid_peak.sum() / nm["pv_kw"]
    off = H[H.scenario.str.match(r"^OFF(_cb\d+)?$")].copy()
    off["capex_bat"] = off["capex_bat"].fillna(P.CAPEX_BAT)
    off = off.pivot_table(index="capex_bat", columns="house", values="total_ann")
    return agg, cost, nm_tab, off


def bilinear(tab, label, cb, m, col):
    t = tab[tab.label == label]
    cbs = np.sort(t.capex_bat.unique())
    ms = np.sort(t.tmult.unique())
    cb = float(np.clip(cb, cbs[0], cbs[-1]))
    m = float(np.clip(m, ms[0], ms[-1]))
    Z = t.pivot(index="capex_bat", columns="tmult", values=col).loc[cbs, ms].values
    zi = np.array([np.interp(m, ms, row) for row in Z])
    return float(np.interp(cb, cbs, zi))


def margin_loss(c, m, credit_peak, nm=False):
    """Lost contribution to fixed cost (PKR per kWp-year) relative to the
    same consumers buying their whole load from the grid. Variable
    procurement cost: system energy charge off-peak, RLNG cost in the
    peak window (the marginal evening resource)."""
    lp, lo = c["load_peak_pk"], c["load_pk"] - c["load_peak_pk"]
    ip, io = c["grid_import_peak_pk"], c["grid_import_pk"] - c["grid_import_peak_pk"]
    ep, eo = c["export_peak_pk"], c["export_pk"] - c["export_peak_pk"]
    rp, ro = m * P.IMP_PEAK, m * P.IMP_OFF
    vp, vo = P.RLNG_COST, ENERGY_CHARGE
    base = lp * (rp - vp) + lo * (ro - vo)
    if nm:   # netting within each ToU period; surplus at NAPPP
        npk, nof = ip - ep, io - eo
        now = (max(npk, 0) * (rp - vp) - max(-npk, 0) * (P.NAPPP - vp) +
               max(nof, 0) * (ro - vo) - max(-nof, 0) * (P.NAPPP - vo))
    else:
        now = ip * (rp - vp) + io * (ro - vo) - ep * (credit_peak - vp) - eo * (P.NAEPP - vo)
    return base - now


def simulate(label, additions_gw=1.0, cap0_gw=7.0, legacy_end=2033,
             bat_decline=0.05, feedback=True, S=None):
    agg, cost, nm_tab, off = S if S is not None else surfaces()
    credit = {"NB": P.NAEPP, "TNB35": 35.0, "TNB46": P.RLNG_COST}[label]
    m, rec = 1.0, []
    for i, yr in enumerate(YEARS):
        cap = cap0_gw + additions_gw * i
        lf = float(np.clip((legacy_end - yr) / (legacy_end - 2026), 0, 1))
        c_leg, c_new = cap * lf, cap * (1 - lf)
        cb = P.CAPEX_BAT * (1 - bat_decline) ** i
        c = {k: bilinear(agg, label, cb, m, k) for k in
             ["bat_kwh_pk", "load_pk", "grid_import_pk", "grid_import_peak_pk",
              "export_pk", "export_peak_pk", "load_peak_pk"]}
        # defection test, house by house
        t = cost.loc[label]
        cbs, ms = np.sort(t.index.get_level_values(0).unique()), np.sort(t.index.get_level_values(1).unique())
        gc = []
        for h in t.columns:
            Z = t[h].unstack().loc[cbs, ms].values
            zi = np.array([np.interp(np.clip(m, ms[0], ms[-1]), ms, row) for row in Z])
            gc.append(np.interp(np.clip(cb, cbs[0], cbs[-1]), cbs, zi))
        gc = np.array(gc)
        oc = np.array([np.interp(np.clip(cb, off.index.min(), off.index.max()),
                                 off.index.values, off[h].values) for h in t.columns])
        defect = float((oc < gc).mean())
        min_ratio = float(np.min(oc / gc))
        loss = (c_leg * 1e6 * margin_loss(nm_tab, m, None, nm=True) +
                c_new * 1e6 * margin_loss(c, m, credit))
        disp = (c_leg * 1e6 * (nm_tab["load_pk"] - nm_tab["grid_import_pk"]) +
                c_new * 1e6 * (c["load_pk"] - c["grid_import_pk"]))
        units = UNITS_XW - disp
        surcharge = loss / units
        peak_red = c_new * 1e6 * (c["load_peak_pk"] - c["grid_import_peak_pk"] + c["export_peak_pk"])
        peak_red += c_leg * 1e6 * (nm_tab["load_peak_pk"] - nm_tab["grid_import_peak_pk"] + nm_tab["export_peak_pk"])
        rec.append(dict(year=yr, label=label, additions=additions_gw,
                        cap_gw=cap, legacy_gw=c_leg, new_gw=c_new, tmult=m,
                        battery_cost=cb, bess_gwh=c_new * c["bat_kwh_pk"],
                        defect_share=defect, min_off_to_grid=min_ratio,
                        lost_contribution_bn=loss / 1e9,
                        displaced_twh=disp / 1e9, surcharge=surcharge,
                        evening_twh=peak_red / 1e9,
                        evening_gw=peak_red / PEAK_HOURS / 1e6,
                        rlng_saving_bn=peak_red * (P.RLNG_COST - ENERGY_CHARGE) / 1e9))
        if feedback:
            m = 1.0 + surcharge / AVG_RETAIL
    return pd.DataFrame(rec)


if __name__ == "__main__":
    S = surfaces()
    out = []
    for lab in ("NB", "TNB35", "TNB46"):
        for add in (0.5, 1.0, 2.0):
            for dec in (0.05, 0.08):
                out.append(simulate(lab, add, bat_decline=dec, S=S).assign(bat_decline=dec))
        out.append(simulate(lab, 1.0, feedback=False, S=S).assign(bat_decline=0.05, feedback=False))
    df = pd.concat(out, ignore_index=True)
    df["feedback"] = df["feedback"].fillna(True)
    df.to_csv(RES / "system_runs.csv", index=False)
    show = df[(df.year.isin([2026, 2030, 2035])) & (df.additions == 1.0) & (df.bat_decline == 0.05)]
    print(show.round(3).to_string())
    print("UNITS_XW TWh", UNITS_XW / 1e9, "FIXED bn", FIXED_COST / 1e9, "AVG_RETAIL", AVG_RETAIL)
