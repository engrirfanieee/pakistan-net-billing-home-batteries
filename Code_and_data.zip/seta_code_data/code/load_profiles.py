"""Build one calendar-year hourly load profile per PRECON house.

Measurement year: 1 Jun 2018 - 31 May 2019. Rows are re-ordered to a
calendar year (Jan-Dec) so that they align, by month-day-hour, with the
PVGIS typical meteorological year. Screening rules:
  (i)  >= 99 % coverage of the 8760-h measurement year;
  (ii) zero-consumption hours (meter outage / vacancy) <= 5 % of the year.
Remaining gaps (hours with <75 % of minutes recorded) are filled with the
house's mean consumption for the same hour of day.
"""
import numpy as np
import pandas as pd
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def build():
    H = pd.read_parquet(ROOT / "data" / "precon_hourly.parquet")
    H = H.loc["2018-06-01 00:00":"2019-05-31 23:00"]
    full = pd.date_range("2018-06-01", "2019-05-31 23:00", freq="h")
    H = H.reindex(full)
    q = pd.DataFrame({"missing_frac": H.isna().mean(),
                      "zero_frac": (H == 0).mean()})
    keep = q[(q.missing_frac <= 0.01) & (q.zero_frac <= 0.05)].index
    excl = q.drop(keep)
    H = H[keep]
    # fill isolated gaps (none expected after screen) with same-hour mean
    H = H.apply(lambda s: s.fillna(s.groupby(s.index.hour).transform("mean")))
    # re-order to calendar year Jan-May (2019) + Jun-Dec (2018)
    cal = pd.concat([H.loc["2019-01-01":"2019-05-31 23:00"],
                     H.loc["2018-06-01":"2018-12-31 23:00"]])
    cal.index = pd.date_range("2023-01-01", periods=8760, freq="h")
    cal.index.name = "local_time_PKT"
    return cal, q, excl


if __name__ == "__main__":
    cal, q, excl = build()
    cal.to_csv(ROOT / "data" / "load_profiles_calendar.csv")
    q.to_csv(ROOT / "data" / "precon_screening.csv")
    print("kept", cal.shape[1], "houses:", list(cal.columns))
    print("excluded:\n", excl.round(3))
    yr = cal.sum()
    print("annual kWh: mean %.0f median %.0f min %.0f max %.0f" %
          (yr.mean(), yr.median(), yr.min(), yr.max()))
