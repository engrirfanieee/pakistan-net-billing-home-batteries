"""Figure 1: modelling framework schematic."""
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch
from pathlib import Path
import figstyle as F

F.apply()
FIG = Path(__file__).resolve().parents[1] / "figures"

fig, ax = plt.subplots(figsize=(7.0, 3.6))
ax.set_xlim(0, 100)
ax.set_ylim(0, 52)
ax.axis("off")


def box(x, y, w, h, title, body, edge):
    ax.add_patch(FancyBboxPatch((x, y), w, h, boxstyle="round,pad=0.4,rounding_size=1.2",
                                fc="white", ec=edge, lw=1.0))
    ax.text(x + w / 2, y + h - 1.6, title, ha="center", va="top", fontsize=7.5,
            fontweight="bold", color=F.INK)
    ax.text(x + w / 2, y + h - 5.0, body, ha="center", va="top", fontsize=6.6,
            color=F.INK2, linespacing=1.35)


def arrow(p, q, rad=0.0):
    ax.add_patch(FancyArrowPatch(p, q, arrowstyle="-|>", mutation_scale=9, lw=0.9,
                                 color=F.INK2, connectionstyle=f"arc3,rad={rad}"))


# inputs
box(1, 35, 22, 15, "Measured demand", "PRECON, Lahore\n34 households, 1-min\nJun 2018 – May 2019", F.S1)
box(1, 18, 22, 15, "Solar resource", "PVGIS TMY 2005–2023\npvlib: Perez, Faiman,\nPVWatts → kWh kWp$^{-1}$", F.S1)
box(1, 1, 22, 15, "Tariffs and costs", "S.R.O. 279(I)/2026 ToU\nProsumer Regulations 2026\nPV, BESS, finance", F.S1)
# household LP
box(30, 14, 28, 30, "Household LP (8760 h)",
    "min annualised capex + O&M\n+ annual energy bill\n\ndecision: PV kWp, BESS kWh,\nhourly flows (perfect foresight)\n\nregimes: GRID · NM · NB ·\nTNB · OFF (LPSP ≤ 1 %)", F.S2)
# outputs
box(65, 33, 33, 17, "Household outcomes",
    "optimal sizing, bills, payback,\nself-sufficiency, evening imports\nand exports, defection test", F.S3)
box(65, 3, 33, 25, "System stock-and-flow model, 2026–2035",
    "prosumer GW → lost contribution\nto fixed cost → per-unit surcharge\n→ retail multiplier m(t)\n\nresponse surface: m × BESS cost\n→ sales, surcharge, evening relief", F.S4)

arrow((23.5, 42), (30, 34))
arrow((23.5, 25.5), (30, 29))
arrow((23.5, 8.5), (30, 22))
arrow((58.5, 34), (65, 40))
arrow((58.5, 22), (65, 17))
# feedback loop
arrow((81, 3.0), (44, 13.0), rad=-0.35)
ax.text(52, 8.5, "tariff feedback m(t)", fontsize=6.6, color=F.INK2, ha="center")
fig.tight_layout()
for ext in ("pdf", "png"):
    fig.savefig(FIG / f"Figure_1.{ext}")
