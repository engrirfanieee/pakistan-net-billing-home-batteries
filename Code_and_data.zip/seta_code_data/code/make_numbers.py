"""Collect every number quoted in the manuscript text into results/numbers.json."""
import json, numpy as np, pandas as pd
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]; RES = ROOT / "results"
H = pd.read_csv(RES / "household_runs.csv"); G = pd.read_csv(RES / "household_grid.csv")
S = pd.read_csv(RES / "system_runs.csv"); S["feedback"] = S.feedback.astype(str) == "True"
N = {}
def sc(s): return H[H.scenario == s].set_index("house")
grid = sc("GRID")
for s in ["NM", "NB", "NB_noBESS", "TNB", "OFF"] + [f"OFF_cb{c}" for c in (20000, 30000, 40000, 60000)]:
    g = sc(s)
    ratio = g.total_with_fixed / grid.total_with_fixed
    N[s] = dict(pv_med=g.pv_kw.median(), bat_med=g.bat_kwh.median(), bat_mean=g.bat_kwh.mean(),
                ratio_med=ratio.median(), ratio_min=ratio.min(), ratio_max=ratio.max(),
                ss_med=100 * g.self_sufficiency.median(), sc_med=100 * g.self_consumption.median(),
                peak_imp_mean=g.grid_import_peak.mean(), exp_peak_mean=g.export_peak.mean(),
                export_mean=g.export.mean(), bat_export_mean=g.bat_export.mean())
for s in H.scenario.unique():
    if s.startswith(("NB_", "TNB_")):
        g = sc(s)
        N[s] = dict(bat_mean=g.bat_kwh.mean(), exp_peak_mean=g.export_peak.mean(),
                    bat_export_mean=g.bat_export.mean(), peak_imp_mean=g.grid_import_peak.mean(),
                    ratio_med=(g.total_with_fixed / grid.total_with_fixed).median())
N["GRID"] = dict(peak_imp_mean=grid.grid_import_peak.mean(), cost_med=grid.total_with_fixed.median())
# response surface: mean battery and peak export vs retail multiplier
for lab in ("NB", "TNB35", "TNB46"):
    for cb in (50000, 30000):
        t = G[(G.label == lab) & (G.capex_bat == cb)].groupby("tmult")[["bat_kwh", "export_peak", "bat_export"]].mean()
        N[f"surf_{lab}_{cb}"] = t.round(1).reset_index().to_dict("list")
def sysrow(lab, add=1.0, dec=0.05, fb=True, yr=2035):
    r = S[(S.label == lab) & (S.additions == add) & (S.bat_decline == dec) & (S.feedback == fb) & (S.year == yr)]
    return r.iloc[0].drop(["label"]).to_dict()
for lab in ("NB", "TNB35", "TNB46"):
    N[f"sys_{lab}_2035"] = sysrow(lab); N[f"sys_{lab}_2030"] = sysrow(lab, yr=2030)
    N[f"sys_{lab}_2035_nofb"] = sysrow(lab, fb=False)
    N[f"sys_{lab}_maxsurch"] = float(S[(S.label == lab) & (S.additions == 1.0) & (S.bat_decline == 0.05) & S.feedback].surcharge.max())
N["sys_2026"] = sysrow("NB", yr=2026)
N["min_off_grid_all"] = float(S.min_off_to_grid.min()); N["defect_max"] = float(S.defect_share.max())
json.dump(N, open(RES / "numbers.json", "w"), indent=1, default=float)
for k in ["NM", "NB", "NB_noBESS", "TNB", "OFF", "OFF_cb20000", "GRID"]: print(k, {a: round(b, 2) for a, b in N[k].items()})
for k in N:
    if k.startswith("surf"): print(k, N[k])
print({k: round(v, 3) if isinstance(v, float) else v for k, v in N["sys_2026"].items()})
for lab in ("NB","TNB35","TNB46"): print(lab, round(N[f"sys_{lab}_maxsurch"],2))
print(N["min_off_grid_all"], N["defect_max"])
