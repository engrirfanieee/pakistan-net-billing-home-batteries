"""Run the household LP for all screened PRECON houses and all scenarios.

Outputs (results/):
  household_runs.csv   one row per (house, scenario)
  net_import_base.npz  hourly net grid import (kWh) per house for base runs
"""
import sys
import itertools
import numpy as np
import pandas as pd
from multiprocessing import Pool
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import params as P
import household_lp as HL

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "results"
OUT.mkdir(exist_ok=True)

L = pd.read_csv(ROOT / "data" / "load_profiles_calendar.csv", index_col=0,
                parse_dates=True)
PV = pd.read_csv(ROOT / "data" / "pv_profile_lahore.csv", index_col=0,
                 parse_dates=True)["pv_kwh_per_kwp"].values
IDX = L.index


def scenarios():
    S = []
    # A. base cases
    S.append(dict(name="GRID", regime="NB", allow_pv=False, allow_bat=False))
    S.append(dict(name="NM", regime="NM"))
    S.append(dict(name="NB", regime="NB"))
    S.append(dict(name="NB_noBESS", regime="NB", allow_bat=False))
    S.append(dict(name="TNB", regime="TNB"))
    S.append(dict(name="OFF", regime="OFF"))
    # B. battery capital cost sweep
    for cb in (20_000, 30_000, 40_000, 60_000):
        for reg in ("NB", "TNB"):
            S.append(dict(name=f"{reg}_cb{cb}", regime=reg, capex_bat=cb))
        S.append(dict(name=f"OFF_cb{cb}", regime="OFF", capex_bat=cb))
    # C. evening export credit sweep (TNB)
    for ep in (11.0, 18.0, 35.0, P.RLNG_COST):
        for cb in (P.CAPEX_BAT, 30_000):
            S.append(dict(name=f"TNB_ep{ep:g}_cb{int(cb)}", regime="TNB",
                          exp_peak=ep, capex_bat=cb))
    # D. retail tariff escalation (feedback loop input)
    for mlt in (1.1, 1.2, 1.3, 1.4, 1.5):
        for reg in ("NB", "TNB"):
            S.append(dict(name=f"{reg}_tm{mlt:g}", regime=reg, tmult=mlt))
        S.append(dict(name=f"GRID_tm{mlt:g}", regime="NB", tmult=mlt,
                      allow_pv=False, allow_bat=False))
    # E. PV capital cost sensitivity
    for cp in (78_750, 131_250):
        for reg in ("NB", "TNB"):
            S.append(dict(name=f"{reg}_cp{cp}", regime=reg, capex_pv=cp))
    return S


def run_one(args):
    house, sc = args
    load = L[house].values
    smax = float(np.ceil(load.max()))
    m = sc.get("tmult", 1.0)
    kw = dict(imp_peak=P.IMP_PEAK * m, imp_off=P.IMP_OFF * m,
              capex_bat=sc.get("capex_bat", P.CAPEX_BAT),
              capex_pv=sc.get("capex_pv", P.CAPEX_PV),
              exp_peak=sc.get("exp_peak"),
              allow_bat=sc.get("allow_bat", True),
              allow_pv=sc.get("allow_pv", True))
    pvmax = None if sc["regime"] == "OFF" else smax
    r = HL.solve(load, PV, IDX, sc["regime"], pv_max=pvmax, export_max=pvmax, **kw)
    if r.get("status") != 0:
        return dict(house=house, scenario=sc["name"], status=r.get("status"))
    f = r.pop("flows")
    net = f["gi"] - f["pe"] - f["be"]
    fixed = P.FIXED_CHARGE * P.FIXED_SHARE * smax * 12 * (sc["regime"] != "OFF")
    r.update(house=house, scenario=sc["name"], sanctioned_kw=smax,
             fixed_charge=fixed, total_with_fixed=r["total_ann"] + fixed,
             tmult=m, capex_bat=kw["capex_bat"], capex_pv=kw["capex_pv"],
             exp_peak=kw["exp_peak"])
    keep_net = sc["name"] in ("GRID", "NM", "NB", "NB_noBESS", "TNB",
                              "TNB_ep45.93_cb50000", "TNB_ep45.93_cb30000",
                              "NB_cb30000", "TNB_cb30000")
    return r, (net.astype(np.float32) if keep_net else None)


if __name__ == "__main__":
    S = scenarios()
    jobs = list(itertools.product(list(L.columns), S))
    print(len(jobs), "LPs")
    rows, nets = [], {}
    with Pool(2) as pool:
        for i, res in enumerate(pool.imap_unordered(run_one, jobs, chunksize=4)):
            if isinstance(res, dict):
                rows.append(res)
                continue
            r, net = res
            rows.append(r)
            if net is not None:
                nets[f"{r['house']}|{r['scenario']}"] = net
            if i % 100 == 0:
                print(i, flush=True)
    df = pd.DataFrame(rows)
    df.to_csv(OUT / "household_runs.csv", index=False)
    np.savez_compressed(OUT / "net_import_base.npz", **nets)
    print("done", df.shape, "failures:", int((df.get("status", 0) != 0).sum()))
