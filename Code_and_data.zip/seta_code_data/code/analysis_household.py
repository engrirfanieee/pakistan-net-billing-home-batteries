"""Tables and figures from the household LP results."""
import sys
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import params as P
import figstyle as F
from household_lp import peak_mask

F.apply()
ROOT = Path(__file__).resolve().parents[1]
RES, FIG = ROOT / "results", ROOT / "figures"
FIG.mkdir(exist_ok=True)

L = pd.read_csv(ROOT / "data" / "load_profiles_calendar.csv", index_col=0, parse_dates=True)
PV = pd.read_csv(ROOT / "data" / "pv_profile_lahore.csv", index_col=0, parse_dates=True)
D = pd.read_csv(RES / "household_runs.csv")
META = pd.read_csv(ROOT / "data" / "precon_metadata.csv")
META["house"] = META["Website Name"].str.extract(r"(\d+)").astype(int)
PK = peak_mask(L.index)


def q(s):
    return f"{np.median(s):,.0f} [{np.percentile(s,25):,.0f}–{np.percentile(s,75):,.0f}]"


def q2(s, d=2):
    return f"{np.median(s):.{d}f} [{np.percentile(s,25):.{d}f}–{np.percentile(s,75):.{d}f}]"


def table_sample():
    yr = L.sum()
    pk = L[PK].sum() / yr
    summer = L[L.index.month.isin([6, 7, 8])].sum() / yr
    peak_kw = L.max()
    m = META.set_index("house").loc[[int(c) for c in L.columns]]
    rows = [
        ("Annual consumption (kWh)", q(yr.values)),
        ("Share of consumption in ToU peak window (%)", q2(100 * pk.values, 1)),
        ("Share of consumption in Jun–Aug (%)", q2(100 * summer.values, 1)),
        ("Maximum hourly demand (kW)", q2(peak_kw.values, 1)),
        ("Air conditioners per house", q2(m.No_of_ACs.values, 0)),
        ("Occupants per house", q2(m.No_of_People.values, 0)),
        ("Three-phase connections (n of 34)", str(int(m.Connection_Type.str.contains("3").sum()))),
    ]
    T = pd.DataFrame(rows, columns=["Characteristic", "Median [IQR]"])
    T.to_csv(RES / "table_sample.csv", index=False)
    # night vs day shares
    night = L[(L.index.hour >= 18) | (L.index.hour < 7)].sum().sum() / yr.sum()
    return T, dict(annual_mean=yr.mean(), annual_total_mwh=yr.sum() / 1e3,
                   night_share=night, peak_share_pooled=L[PK].sum().sum() / yr.sum())


def table_regimes():
    names = {"GRID": "Grid only", "NM": "Net metering (legacy)",
             "NB_noBESS": "Net billing, PV only", "NB": "Net billing, PV + BESS",
             "TNB": "TNB (evening credit = NAPPP)", "OFF": "Grid defection"}
    rows = []
    g0 = D[D.scenario == "GRID"].set_index("house")
    for k, lab in names.items():
        g = D[D.scenario == k].set_index("house")
        rel = g.total_with_fixed / g0.loc[g.index].total_with_fixed
        rows.append(dict(Regime=lab, PV_kWp=q2(g.pv_kw, 1), BESS_kWh=q2(g.bat_kwh.clip(lower=0), 1),
                         Grid_import_MWh=q2(g.grid_import / 1e3, 2),
                         Peak_import_MWh=q2(g.grid_import_peak / 1e3, 2),
                         Export_MWh=q2(g.export / 1e3, 2),
                         Self_sufficiency_pct=q2(100 * g.self_sufficiency, 0),
                         Annual_cost_kPKR=q(g.total_with_fixed / 1e3),
                         Cost_vs_grid=q2(rel, 2)))
    T = pd.DataFrame(rows)
    T.to_csv(RES / "table_regimes.csv", index=False)
    return T


def payback():
    """Simple payback of the optimal NB and NM investments vs grid only."""
    out = {}
    g0 = D[D.scenario == "GRID"].set_index("house")
    for k in ("NM", "NB_noBESS", "NB"):
        g = D[D.scenario == k].set_index("house")
        capex = g.pv_kw * P.CAPEX_PV + g.bat_kwh * (P.CAPEX_BAT + P.CAPEX_HYB * P.C_RATE)
        saving = g0.loc[g.index].energy_cost - g.energy_cost - g.pv_kw * P.CAPEX_PV * P.OM_PV
        out[k] = (capex / saving)
    return pd.DataFrame(out)


def fig_profiles(stats):
    fig, axes = plt.subplots(1, 2, figsize=(7.0, 2.9), sharey=True)
    pv = PV["pv_kwh_per_kwp"]
    med_pv = D[D.scenario == "NB"].pv_kw.median()
    for ax, months, title in ((axes[0], [6, 7, 8], "(a) June–August"),
                              (axes[1], [12, 1, 2], "(b) December–February")):
        sel = L.index.month.isin(months)
        h = L.index.hour[sel]
        lm = L[sel].mean(axis=1).groupby(h).mean()
        lq1 = L[sel].groupby(h).mean().quantile(0.25, axis=1)
        lq3 = L[sel].groupby(h).mean().quantile(0.75, axis=1)
        pm = pv[sel].groupby(h).mean() * med_pv
        a, b = P.PEAK_WINDOW[months[0]]
        ax.axvspan(a - 0.5, b - 0.5, color=F.PEAK_FILL, zorder=0, lw=0)
        ax.text((a + b) / 2 - 0.5, 0.97, "ToU peak", ha="center", va="top",
                transform=ax.get_xaxis_transform(), color=F.INK2, fontsize=7)
        ax.fill_between(lm.index, lq1, lq3, color=F.S1, alpha=0.18, lw=0)
        ax.plot(lm.index, lm.values, color=F.S1, label="Household demand (mean; IQR band)")
        ax.plot(pm.index, pm.values, color=F.S2, ls="--",
                label=f"PV output, {med_pv:.0f} kWp (median optimal size)")
        ax.set_title(title, loc="left", fontsize=8)
        ax.set_xlim(-0.5, 23.5)
        ax.set_xticks(range(0, 24, 3))
        ax.set_xlabel("Hour of day (PKT)")
    axes[0].set_ylabel("Average power (kW)")
    h_, l_ = axes[0].get_legend_handles_labels()
    fig.legend(h_, l_, loc="lower center", ncol=2, fontsize=7)
    fig.tight_layout(rect=(0, 0.08, 1, 1))
    for ext in ("pdf", "png"):
        fig.savefig(FIG / f"Figure_2.{ext}")
    plt.close(fig)


def fig_costs():
    order = ["GRID", "NM", "NB_noBESS", "NB", "TNB", "OFF"]
    labels = ["Grid\nonly", "Net\nmetering", "Net billing\nPV only", "Net billing\nPV+BESS",
              "TNB\n(NAPPP)", "Grid\ndefection"]
    fig, ax = plt.subplots(figsize=(7.0, 2.8))
    g0 = D[D.scenario == "GRID"].set_index("house").total_with_fixed
    rng = np.random.default_rng(1)
    for i, k in enumerate(order):
        g = D[D.scenario == k].set_index("house").total_with_fixed
        rel = (g / g0.loc[g.index]).values
        x = i + rng.uniform(-0.18, 0.18, len(rel))
        ax.scatter(x, rel, s=10, color=F.S1, alpha=0.75, lw=0, zorder=3)
        med = np.median(rel)
        ax.plot([i - 0.3, i + 0.3], [med, med], color=F.INK, lw=1.4, zorder=4)
        ax.text(i + 0.33, med, f"{med:.2f}", va="center", fontsize=7, color=F.INK)
    ax.axhline(1.0, color=F.INK2, lw=0.8, ls=":")
    ax.set_xticks(range(len(order)))
    ax.set_xticklabels(labels)
    ax.set_ylabel("Equivalent annual cost\nrelative to grid only (–)")
    ax.set_ylim(-0.2, None)
    fig.tight_layout()
    for ext in ("pdf", "png"):
        fig.savefig(FIG / f"Figure_3.{ext}")
    plt.close(fig)


def fig_battery_cost():
    cbs = [20_000, 30_000, 40_000, 50_000, 60_000]

    def pick(reg, cb, ep=None):
        if ep is None:
            name = reg if cb == 50_000 else f"{reg}_cb{cb}"
        else:
            name = f"TNB_ep{ep:g}_cb{cb}"
        return D[D.scenario == name]
    fig, axes = plt.subplots(1, 2, figsize=(7.0, 3.0))
    series = [("Net billing", lambda cb: pick("NB", cb), F.S1, "o", "-"),
              ("TNB, credit = NAPPP", lambda cb: pick("TNB", cb), F.S2, "s", "--")]
    for lab, fn, col, mk, ls in series:
        y = [fn(cb).bat_kwh.mean() for cb in cbs]
        z = [fn(cb).grid_import_peak.mean() / 1e3 for cb in cbs]
        axes[0].plot(np.array(cbs) / 1e3, y, color=col, marker=mk, ms=4, ls=ls, label=lab)
        axes[1].plot(np.array(cbs) / 1e3, z, color=col, marker=mk, ms=4, ls=ls, label=lab)
    # credit = RLNG cost at two battery costs
    for cb, mk in ((30_000, "^"), (50_000, "^")):
        g = pick("TNB", cb, P.RLNG_COST)
        axes[0].scatter([cb / 1e3], [g.bat_kwh.mean()], color=F.S3, marker=mk, s=22, zorder=5,
                        label=f"TNB, credit = RLNG cost (PKR {P.RLNG_COST:g})" if cb == 30_000 else None)
        axes[1].scatter([cb / 1e3], [g.grid_import_peak.mean() / 1e3], color=F.S3, marker=mk, s=22, zorder=5)
    g0 = D[D.scenario == "GRID"].grid_import_peak.mean() / 1e3
    axes[1].axhline(g0, color=F.INK2, ls=":", lw=0.8)
    axes[1].text(21, g0 + 0.02, "grid only", ha="left", va="bottom", fontsize=7, color=F.INK2)
    axes[0].set_ylabel("Optimal battery capacity (kWh)")
    axes[1].set_ylabel("Peak-window grid import (MWh yr$^{-1}$)")
    for ax, t in zip(axes, ("(a)", "(b)")):
        ax.set_xlabel("Battery capital cost (kPKR kWh$^{-1}$)")
        ax.set_title(t, loc="left", fontsize=8)
        ax.set_ylim(0, None)
    axes[0].set_ylim(0, 24)
    axes[1].set_ylim(-0.05, 1.6)
    h_, l_ = axes[0].get_legend_handles_labels()
    fig.legend(h_, l_, loc="lower center", ncol=3, fontsize=7)
    fig.tight_layout(rect=(0, 0.08, 1, 1))
    for ext in ("pdf", "png"):
        fig.savefig(FIG / f"Figure_4.{ext}")
    plt.close(fig)


def fig_duck():
    Z = np.load(RES / "net_import_base.npz")
    houses = list(L.columns)
    sel = L.index.month.isin([6, 7, 8])
    h = L.index.hour[sel]
    fig, ax = plt.subplots(figsize=(7.0, 2.8))
    a, b = P.PEAK_WINDOW[7]
    ax.axvspan(a - 0.5, b - 0.5, color=F.PEAK_FILL, zorder=0, lw=0)
    ax.text((a + b) / 2 - 0.5, 0.97, "ToU peak", ha="center", va="top",
            transform=ax.get_xaxis_transform(), color=F.INK2, fontsize=7)
    spec = [("GRID", "Grid only", F.INK2, ":"),
            ("NB_noBESS", "Net billing, PV only", F.S1, "-"),
            ("NB", "Net billing, PV + BESS (PKR 50k kWh$^{-1}$)", F.S2, "--"),
            ("TNB_ep45.93_cb30000", "TNB, RLNG-cost credit (PKR 30k kWh$^{-1}$)", F.S3, "-.")]
    for key, lab, col, ls in spec:
        M = np.stack([Z[f"{hh}|{key}"] for hh in houses], axis=1).sum(axis=1)[sel]
        y = pd.Series(M).groupby(h.values).mean() / len(houses)
        ax.plot(y.index, y.values, color=col, ls=ls, label=lab)
    ax.axhline(0, color=F.INK, lw=0.6)
    ax.set_xlim(-0.5, 23.5)
    ax.set_xticks(range(0, 24, 3))
    ax.set_xlabel("Hour of day (PKT), June–August")
    ax.set_ylabel("Mean net grid import\nper household (kW)")
    ax.legend(fontsize=7, loc="lower left", ncol=2)
    fig.tight_layout()
    for ext in ("pdf", "png"):
        fig.savefig(FIG / f"Figure_5.{ext}")
    plt.close(fig)
    # numbers for text
    out = {}
    for key, *_ in spec:
        M = np.stack([Z[f"{hh}|{key}"] for hh in houses], axis=1).sum(axis=1)
        out[key] = dict(peak_mean_kw=M[PK].mean() / len(houses),
                        summer_peak_mean_kw=M[PK & L.index.month.isin([6, 7, 8])].mean() / len(houses),
                        min_kw=M.min() / len(houses))
    return out


if __name__ == "__main__":
    T1, st = table_sample()
    print(T1.to_string(), st)
    T2 = table_regimes()
    print(T2.T.to_string())
    pb = payback()
    print("payback median/IQR:\n", pb.describe(percentiles=[.25, .5, .75]).round(2))
    fig_profiles(st)
    fig_costs()
    fig_battery_cost()
    print(fig_duck())
