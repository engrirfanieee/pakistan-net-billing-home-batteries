"""Figure 6 and system tables."""
import sys
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import figstyle as F

F.apply()
ROOT = Path(__file__).resolve().parents[1]
RES, FIG = ROOT / "results", ROOT / "figures"
S = pd.read_csv(RES / "system_runs.csv")
S["feedback"] = S["feedback"].astype(str) == "True"

LAB = {"NB": ("Net billing (NAEPP)", F.S1, "o", "-"),
       "TNB35": ("TNB, evening credit PKR 35", F.S2, "s", "--"),
       "TNB46": ("TNB, evening credit = RLNG cost", F.S3, "^", "-.")}


def fig_system():
    fig, axes = plt.subplots(1, 3, figsize=(7.0, 2.7))
    cols = [("surcharge", "Fixed-cost surcharge (PKR kWh$^{-1}$)"),
            ("bess_gwh", "Prosumer BESS (GWh)"),
            ("evening_gw", "Evening demand reduction (GW)")]
    for ax, (c, ylab), t in zip(axes, cols, ("(a)", "(b)", "(c)")):
        for lab, (name, col, mk, ls) in LAB.items():
            base = S[(S.label == lab) & (S.additions == 1.0) & (S.bat_decline == 0.05) & S.feedback]
            lo = S[(S.label == lab) & (S.additions == 0.5) & (S.bat_decline == 0.05) & S.feedback]
            hi = S[(S.label == lab) & (S.additions == 2.0) & (S.bat_decline == 0.05) & S.feedback]
            ax.fill_between(base.year, lo[c].values, hi[c].values, color=col, alpha=0.12, lw=0)
            ax.plot(base.year, base[c], color=col, marker=mk, ms=3, ls=ls, label=name)
        ax.set_title(t, loc="left", fontsize=8)
        ax.set_ylabel(ylab)
        ax.set_xticks([2026, 2028, 2030, 2032, 2034])
        ax.set_ylim(0, None)
    h, l = axes[0].get_legend_handles_labels()
    fig.legend(h, l, loc="lower center", ncol=3, fontsize=7)
    fig.tight_layout(rect=(0, 0.08, 1, 1))
    for ext in ("pdf", "png"):
        fig.savefig(FIG / f"Figure_6.{ext}")
    plt.close(fig)


def table_system():
    rows = []
    for lab, (name, *_ ) in LAB.items():
        for add in (0.5, 1.0, 2.0):
            for dec in (0.05, 0.08):
                g = S[(S.label == lab) & (S.additions == add) & (S.bat_decline == dec) & S.feedback]
                r = g[g.year == 2035].iloc[0]
                rows.append(dict(Regime=name, Additions_GW_yr=add, Battery_cost_decline=dec,
                                 Prosumer_GW_2035=r.cap_gw, BESS_GWh=r.bess_gwh,
                                 Displaced_TWh=r.displaced_twh, Lost_contribution_bn=r.lost_contribution_bn,
                                 Surcharge=r.surcharge, Retail_multiplier=r.tmult,
                                 Evening_TWh=r.evening_twh, Evening_GW=r.evening_gw,
                                 Fuel_saving_bn=r.rlng_saving_bn, Defect_share=r.defect_share,
                                 Min_off_grid_ratio=g.min_off_to_grid.min()))
    T = pd.DataFrame(rows)
    T.to_csv(RES / "table_system_2035.csv", index=False)
    return T


if __name__ == "__main__":
    fig_system()
    print(table_system().round(2).to_string())
