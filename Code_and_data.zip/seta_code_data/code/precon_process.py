"""Aggregate PRECON one-minute household data to hourly energy.

Input : data/precon_raw/House*.csv  (Nadeem & Arshad 2019; CC0 licence)
Output: data/precon_hourly.parquet  (hourly kWh per house, local time)
        data/precon_quality.csv      (coverage statistics per house)
"""
import glob
import re
import numpy as np
import pandas as pd
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def process():
    hourly, qual = {}, []
    files = sorted(glob.glob(str(ROOT / "data" / "precon_raw" / "House*.csv")),
                   key=lambda s: int(re.findall(r"House(\d+)", s)[0]))
    for f in files:
        hid = int(re.findall(r"House(\d+)", f)[0])
        d = pd.read_csv(f, usecols=["Date_Time", "Usage_kW"])
        d["Date_Time"] = pd.to_datetime(d["Date_Time"])
        d = d.set_index("Date_Time")["Usage_kW"]
        d = d[~d.index.duplicated()]
        neg = int((d < 0).sum())
        d = d.clip(lower=0)
        # minutes recorded per hour; energy = mean kW * 1 h
        g = d.resample("h")
        n = g.count()
        e = g.mean()
        e[n < 45] = np.nan               # require >=75 % of minutes
        hourly[hid] = e
        qual.append(dict(house=hid, start=d.index.min(), end=d.index.max(),
                         minutes=len(d), negative_values=neg,
                         valid_hours=int(e.notna().sum()),
                         zero_hours=int((e == 0).sum()),
                         mean_kW=float(d.mean())))
    H = pd.DataFrame(hourly)
    H.index.name = "local_time_PKT"
    Q = pd.DataFrame(qual)
    return H, Q


if __name__ == "__main__":
    H, Q = process()
    H.to_parquet(ROOT / "data" / "precon_hourly.parquet")
    Q.to_csv(ROOT / "data" / "precon_quality.csv", index=False)
    print(Q.to_string())
    print(H.index.min(), H.index.max(), H.shape)
