# Code and data: Home batteries under net billing (Pakistan)

Pipeline (Python 3, pvlib 0.16.1, SciPy/HiGHS, pandas, matplotlib):
1. `code/pv_model.py` – hourly PV yield from the PVGIS TMY (download the TMY for 31.520 N, 74.360 E from PVGIS and place it in `data/pvgis_tmy_lahore.csv`).
2. `code/precon_process.py`, `code/load_profiles.py` – hourly profiles from PRECON (CC0; download from opendata.com.pk) and screening.
3. `code/run_household.py`, `code/run_grid.py` – household LPs (1,530 + 2,448 runs).
4. `code/system_model.py` – stock-and-flow model 2026–2035.
5. `code/analysis_household.py`, `code/analysis_system.py`, `code/fig_framework.py` – tables and figures.
6. `code/make_numbers.py` – every number quoted in the manuscript (`results/numbers.json`).

`data/` holds the processed hourly demand (34 houses) and PV yield; `results/` holds all model outputs.
`results/table_system_2035.csv` contains the supplementary system results (including the 8%/yr battery-cost decline cases).
